from fastapi import FastAPI, HTTPException, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware #es para el cors
from app.persistencia import crear_tabla_hoja_de_vida
f

app = FastAPI(
    title="API Gestión de Usuarios",
    description="API para administrar usuarios del sistema",
    version="1.0.0",
    contact={
        "name": "Carlos Caceres",
        "url": "https://miweb.com",
        "email": "carlos@email.com"
    },
    license_info={
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT"
    }
)

# ⚡ Habilitar CORS
origins = [
    "http://127.0.0.1:5500",  # tu frontend
    "http://localhost:5500",  # opcional, si usas localhost
    "http://localhost:8000"   # opcional, si quieres que tu backend se llame a sí mismo
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # permite estos orígenes
    allow_credentials=True,
    allow_methods=["*"],    # permite GET, POST, etc.
    allow_headers=["*"],    # permite headers
)

# creación de bucket S3
@app.post("/create-table/hoja-vida")
async def create_hoja_vida_table():
    try:
        result = crear_tabla_hoja_de_vida()
        if result["success"]:
            return result
        else:
            raise HTTPException(status_code=500, detail=result["message"])
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

