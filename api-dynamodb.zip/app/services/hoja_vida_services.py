from app.persistencia.crear_tabla_hoja_de_vida import crear_tabla_hojas_vida


def crear_tabla_hoja_de_vida():
    return crear_tabla_hojas_vida()